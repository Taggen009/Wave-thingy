extends Sprite2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	expand_pool_simple()

var blood_pool_sizex = randf_range(0.4, 0.5)
var blood_pool_sizey = randf_range(0.4, 0.5)

func expand_pool_simple():
	var tween = create_tween()
	tween.tween_property(self, "scale", Vector2(blood_pool_sizex, blood_pool_sizey), 7.0)
	
