extends Sprite2D


var velocity = Vector2.RIGHT
var speed = 700

var look_once = true

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if look_once:
		look_at(get_global_mouse_position())
		look_once = false
	global_position += velocity.rotated(rotation) * speed * delta	


func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	queue_free()
