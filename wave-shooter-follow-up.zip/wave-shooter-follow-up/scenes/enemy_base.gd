extends CharacterBody2D

@export var speed: int = 100
@export var movement_target : Node2D


var dead = false
var bloodspray = false
var bloodpool = false
var bat_death = false
var follow_up_stop = true
var stun = true
@export var HP: int = 1

var enemy_type = ["Attack1", "Attack2"]
var enemy_poses1 = ["1", "2", "3", "4"]
var enemy_poses_bat1 = ["Zombie_dead_bat1", "Zombie_dead_bat2", "Zombie_dead_bat3"]
var enemy_poses_bat1_followup = ["Zombie_dead_bat1", "Zombie_dead_bat2", "Zombie_dead_bat4"]
var enemy2_poses_bat1 = ["Zombie2_dead_bat1", "Zombie2_dead_bat2", "Zombie2_dead_bat3"]
var enemy2_poses_bat1_followup = ["Zombie2_dead_bat1", "Zombie2_dead_bat2", "Zombie2_dead_bat4"]
var enemy_poses2 = ["Zombie2_dead1", "Zombie2_dead2", "Zombie2_dead3", "Zombie2_dead4"]

var random_pose1 = enemy_poses1.pick_random()
var random_pose_bat1 = enemy_poses_bat1.pick_random()
var random_pose_bat1_followup = enemy_poses_bat1_followup.pick_random()
var random_pose_bat2 = enemy2_poses_bat1.pick_random()
var random_pose_bat2_followup = enemy2_poses_bat1_followup.pick_random()
var random_pose2 = enemy_poses2.pick_random()
var random_type = enemy_type.pick_random()

var blood = preload("res://scenes/blood.tscn")
var bullet = preload("res://scenes/bullet.tscn")
var blood_pool_scene = preload("res://scenes/blood_pool.tscn")
var blood_splat = preload("res://scenes/blood_splat.tscn")
var Player = preload("res://scenes/player.tscn")


@onready var enemy: Sprite2D = $Enemy_base
@onready var animated_sprite: AnimatedSprite2D = $Enemy_base/AnimatedSprite2D
@onready var collision_shape_: CollisionShape2D = $Enemy_base/Hitbox/CollisionShape2D
@onready var blood_mist: CPUParticles2D = $Enemy_base/Blood_mist
@onready var collision_shape_2d: CollisionShape2D = $CollisionShape2D

@onready var bat_hit: AudioStreamPlayer2D = $bat_hit





func basic_movement_towards_player(delta):
	if Global.player != null and dead == false:
		pass


		
func _on_hitbox_area_entered(area: Area2D) -> void:
	if area.is_in_group("Enemy_damager") and dead == false:
		HP -= 1
		await get_tree().create_timer(0.01).timeout
		blood_mist.restart()

	elif area.is_in_group("Enemy_damager_melee") and dead == false and Global.melee == -1:
		bat_hit.play()
		dead = true	
		var blood_splat_instance = Global.instance_node(blood_splat, global_position, Global.node_creation_parent)
		blood_splat_instance.rotation = global_position.angle_to_point(Global.player.global_position) + PI
		


		
func pooling():
	var spawn_pos = global_position
	spawn_pos = $Enemy_base/Belly_shot.global_position
	
	var blood_pool = Global.instance_node(blood_pool_scene, global_position, Global.node_creation_parent)
	blood_pool.global_position = spawn_pos
	blood_pool.rotation = randf_range(0, TAU)

func pooling_head():
	var spawn_pos = global_position
	spawn_pos = $Enemy_base/Head_shot.global_position
	
	var blood_pool = Global.instance_node(blood_pool_scene, global_position, Global.node_creation_parent)
	blood_pool.global_position = spawn_pos
	blood_pool.rotation = randf_range(0, TAU)
	
				


func _ready() -> void:
	pass
	
func _process(delta: float) -> void:
	pass
		
