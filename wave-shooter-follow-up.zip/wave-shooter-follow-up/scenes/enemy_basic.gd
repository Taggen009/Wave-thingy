extends "enemy_base.gd"



# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	speed = randf_range(100, 130)
	
	
	$NavigationAgent2D.target_position = Global.player.global_position
	

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
		
	
	basic_movement_towards_player(delta)
	

	if HP <= 0:
		dead = true
	
	if dead == false:
		
		if not $NavigationAgent2D.is_target_reached():
			var point_direction = $NavigationAgent2D.get_next_path_position()
			velocity = (point_direction - global_position).normalized() * speed 
			look_at(point_direction)
		else:
			velocity = Vector2.ZERO	
			
		animated_sprite.play(random_type)
		move_and_slide()	
			
		
		
	else:
		
		
		enemy.scale.x = -0.5
		
		
		animated_sprite.z_index = -6
		
		collision_shape_.disabled = true
		collision_shape_2d.disabled = true
		
	
				
		if bloodspray == false:
				
				
			velocity = -velocity * 20
				
			global_position	+= velocity * delta
				
			if Global.camera != null:
				Global.camera.screen_shake(80, 0.2)
				
			if Global.melee == -1:
				bat_death = true
				
			if bat_death == true:
				pooling_head()		
					
			bloodspray = true
			Global.score += 10
				
			var blood_instance = Global.instance_node(blood, global_position, Global.node_creation_parent)
			blood_instance.rotation = global_position.angle_to_point(Global.player.global_position) + PI
			if random_type == "Attack1":
				if random_pose1 in ["1", "2", "3"] and bat_death == false:
					pooling()
					bloodpool = true
				else:
					pooling_head()	
			if random_type == "Attack2":
				if random_pose2 in ["Zombie2_dead1", "Zombie2_dead2", "Zombie2_dead3"] and bat_death == false:
					pooling()
				else:
					pooling_head()					
					
		if random_type == "Attack1":
			if bat_death == true:
				if Global.first_swing == false and follow_up_stop == true:
					animated_sprite.play(random_pose_bat1_followup)
					follow_up_stop = false
							
				else:
					animated_sprite.play(random_pose_bat1)
				
								
			else:	
				animated_sprite.play(random_pose1)
		else:
			if bat_death == true:
				if Global.first_swing == false and follow_up_stop == true:
					animated_sprite.play(random_pose_bat2)
					follow_up_stop = false
						
						
				else:
					animated_sprite.play(random_pose_bat2_followup)
		
											
			else:	
				animated_sprite.play(random_pose2)
					
		enemy.scale.x = -1.5		
			
func _on_timer_timeout() -> void:
	if $NavigationAgent2D.target_position != Global.player.global_position:
		$NavigationAgent2D.target_position = Global.player.global_position
	$Timer.start()
						
		
	

	
		
		
