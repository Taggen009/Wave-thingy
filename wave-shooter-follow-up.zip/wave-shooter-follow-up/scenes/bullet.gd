extends CharacterBody2D

@onready var bullet_body: CollisionShape2D = $CollisionShape2D
@onready var dust: CPUParticles2D = $Dust

var direction = Vector2.RIGHT
var speed = 140

var look_once = true

func _ready():
	direction = Vector2.RIGHT.rotated(global_rotation)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	velocity += direction * speed * delta
	
	var collision = move_and_collide(velocity)
	
	if collision:
		dust.emitting = true
		queue_free()



func _on_visible_on_screen_notifier_2d_screen_exited() -> void:
	queue_free()


func _on_hitbox_area_entered(area: Area2D) -> void:
	if area.is_in_group("Enemy"):
		queue_free()
		
