extends "enemy_base.gd"

var death_pose = ["Zombie_swat_dead1", "Zombie_swat_dead2", "Zombie_swat_dead3", "Zombie_swat_dead4"]

var random_pose = death_pose.pick_random()

var stunned = false

@onready var stun_timer: Timer = $Stun


func _ready() -> void:
	stun = false
	enemy.scale.x = 2
	enemy.scale.y = 2
	
	$NavigationAgent2D.target_position = Global.player.global_position


func _process(delta: float) -> void:

	
	basic_movement_towards_player(delta)
	
	
	
	if HP <= 0:
		dead = true
	
	if dead == false:
		
		if not $NavigationAgent2D.is_target_reached():
			var point_direction = $NavigationAgent2D.get_next_path_position()
			velocity = (point_direction - global_position).normalized() * speed 
			look_at(point_direction)
			
		animated_sprite.play("Zombie_swat_attack")
		move_and_slide()	
			
		
	
			
	else:
		
		
		animated_sprite.z_index = -6
		
		if bat_death == false:
			animated_sprite.play(random_pose)
		else:
			animated_sprite.play("Zombie_swat_dead4")
			
			
		collision_shape_.disabled = true
		collision_shape_2d.disabled = true
		if bloodspray == false:
			
			velocity = -velocity * 15
			
			global_position	+= velocity * delta
			
			if Global.camera != null:
				Global.camera.screen_shake(80, 0.2)
			
			if Global.melee == -1:
				bat_death = true
			
			if bat_death == true:
				pooling_head()		
				
			bloodspray = true
			Global.score += 10
			
			var blood_instance = Global.instance_node(blood, global_position, Global.node_creation_parent)
			blood_instance.rotation = global_position.angle_to_point(Global.player.global_position) + PI
			
			if random_pose in ["Zombie_swat_dead1", "Zombie_swat_dead2", "Zombie_swat_dead3"] and bat_death == false:
				pooling()
				bloodpool = true
			else:
				pooling_head()	
				
		enemy.scale.x = -2			
		

func _on_timer_timeout() -> void:
	if $NavigationAgent2D.target_position != Global.player.global_position:
		$NavigationAgent2D.target_position = Global.player.global_position
	$Timer.start()
			


func _on_stun_timeout() -> void:
	pass
	
