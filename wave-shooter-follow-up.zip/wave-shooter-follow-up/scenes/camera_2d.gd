extends Camera2D

var screen_shake_start = false
var shake_intesity = 0

@export var pan_strength: float = 0.25  
@export var follow_speed: float = 5.0 


@onready var crosshair: Sprite2D = %crosshair


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	Global.camera = self

	
func _exit_tree() -> void:
	Global.camera = null

func _process(delta: float) -> void:
	
	var mouse_offset = crosshair.global_position
	
	var target_pos = mouse_offset * pan_strength
	
	position = position.lerp(target_pos, follow_speed * delta)
	
	zoom = lerp(zoom, Vector2(1, 1), 0.3)

	if screen_shake_start == true:
		global_position += Vector2(randf_range(-shake_intesity, shake_intesity), randf_range(-shake_intesity, shake_intesity))	* delta	
	

func screen_shake(intensity, time):
	zoom = Vector2(1, 1) - Vector2(intensity * 0.0015, intensity * 0.002)
	shake_intesity = intensity
	$screen_shake_time.wait_time = time
	$screen_shake_time.start()
	screen_shake_start = true

func _on_screen_shake_time_timeout() -> void:
	screen_shake_start = false
