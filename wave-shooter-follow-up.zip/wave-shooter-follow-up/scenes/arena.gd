extends Node2D

var enemy = 0

@export var enemies: Array[PackedScene]

func _ready() -> void:
	$fade_transition/AnimationPlayer.play("fade_out")
	Global.node_creation_parent = self
	
	Global.score = 0
	
func _exit_tree():
	Global.node_creation_parent = null	

func _on_enemy_spawn_timer_timeout() -> void:
	var enemy_position = Vector2(randf_range(-160, 670), randf_range(-90, 390))
	
	while enemy_position.x < 640 and enemy_position.x > -80 and enemy_position.y < 360 and enemy_position.y > -45:
		enemy_position = Vector2(randf_range(-160, 670), randf_range(-90, 390))
	
	var enemy_number = round(randf_range(0, 10))
	
	if enemy_number < 9:
		enemy = 0
	else:
		enemy = 1	
	
	Global.instance_node(enemies[enemy], enemy_position, self)	
	

func _on_difficulty_timer_timeout() -> void:
	if $Enemy_spawn_timer.wait_time > 0.5:
		$Enemy_spawn_timer.wait_time -= 0.05
