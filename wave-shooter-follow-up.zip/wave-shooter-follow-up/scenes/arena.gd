extends Node2D

var enemy = 0

@export var enemies: Array[PackedScene]
@onready var blocker: CollisionShape2D = $BlockerBody/Blocker

func _ready() -> void:
	$fade_transition/AnimationPlayer.play("fade_out")
	blocker.disabled = true
	Global.node_creation_parent = self
	
	Global.score = 0
	
func _exit_tree():
	Global.node_creation_parent = null	

func _on_enemy_spawn_timer_timeout() -> void:
	if blocker.disabled == true:
		pass
	else:	
		var enemy_position = $Spawn_point1.global_position
		var spawn_point = round(randf_range(1, 8))
		
		if spawn_point == 1:
			enemy_position = $Spawn_point1.global_position
		elif spawn_point == 7:
			enemy_position = $Spawn_point1.global_position		
		elif spawn_point == 2:
			enemy_position = $Spawn_point2.global_position	
		elif spawn_point == 3:
			enemy_position = $Spawn_point3.global_position
		elif spawn_point == 4:
			enemy_position = $Spawn_point4.global_position	
		elif spawn_point == 5:
			enemy_position = $Spawn_point5.global_position
		else:
			enemy_position = $Spawn_point6.global_position							
		
		var enemy_number = round(randf_range(0, 10))
		
		if enemy_number < 10:
			enemy = 0
		else:
			enemy = 1	
		
		Global.instance_node(enemies[enemy], enemy_position, self)	
	

func _on_difficulty_timer_timeout() -> void:
	if $Enemy_spawn_timer.wait_time > 0.5 and blocker.disabled == false:
		$Enemy_spawn_timer.wait_time -= 0.05


func _on_entrance_area_entered(area: Area2D) -> void:
	blocker.set_deferred("disabled", false)
