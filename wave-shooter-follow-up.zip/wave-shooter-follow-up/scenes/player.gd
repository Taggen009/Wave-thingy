extends CharacterBody2D

var bullet = preload("res://scenes/bullet.tscn")
@export var bullet_count: int = 1
@export_range(0, 360) var arc: float = 0
@export_range(0, 20) var fire_rate: float = 2.0
@export var crosshair_leash: int = 200
@export var barrel_origin: Sprite2D

@onready var crosshair: Sprite2D = %crosshair
@onready var shotgun_audio: AudioStreamPlayer2D = $Shotgun_audio
@onready var hitbox_bat: Area2D = $Player/Hitbox_bat
@onready var collision_shape: CollisionShape2D = $Player/Hitbox_bat/CollisionShape2D

@onready var node_2d: CharacterBody2D = $"."

var can_shoot = true
var is_alive = true
var walking = true


var speed = 200



func _ready():
	Global.player = self
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	node_2d.global_position = animated_sprite.global_position

	
func _exit_tree():
	Global.player = null	

@onready var animated_sprite: AnimatedSprite2D = $Player/AnimatedSprite2D

func _input(event):
	if event is InputEventMouseMotion and is_alive:
		crosshair.global_position += event.relative
	
func _physics_process(delta: float) -> void:
	
	
	if Input.is_action_pressed("Escape"):
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
		
	if Input.is_action_pressed("Lock_mouse"):
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)	
		
	var direction := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	
	if direction != Vector2.ZERO:
		velocity = direction * speed
	else:
		velocity = velocity.move_toward(Vector2.ZERO, speed)	
	
	move_and_slide()
	
	if is_alive == true:
		
		

		var cursor_movement = velocity * delta
		
		crosshair.global_position += cursor_movement
		
		look_at(crosshair.global_position)
		
		var mouse_offset = crosshair.global_position
		
		if mouse_offset.length() > crosshair_leash:
			
			var restricted_offset = mouse_offset.limit_length(crosshair_leash)
			
		
			var global_target = global_position + restricted_offset
			var screen_target = get_viewport().get_canvas_transform() * global_target
		
	
	if Input.is_action_just_pressed("shoot") and is_alive and can_shoot == true and Global.melee == 1:
		shotgun_audio.play()
		shoot()
		
	if Input.is_action_just_pressed("shoot") and walking == true and Global.melee == -1 and is_alive == true:
		melee_attack()	
	
	if Input.is_action_just_pressed("Switch_weapon"):
		Global.melee *= -1
		
	if Global.melee == 1 and walking == true:
		animated_sprite.play("Armed")
	elif Global.melee == -1 and walking == true and Global.first_swing == false:
		animated_sprite.play("Armed_bat")
	elif Global.melee == -1 and walking == true and Global.first_swing == true:
		animated_sprite.play("Armed_bat2")	
			

	
	if walking == true:
		collision_shape.disabled = true
	elif walking == false and Global.melee == -1:
		collision_shape.disabled = false
			
	
					
		
func shoot():
	if can_shoot and is_alive == true and Global.melee == 1:
		can_shoot = false
		walking = false
		animated_sprite.play("shoot")
		for i in bullet_count:
			var new_bullet = bullet.instantiate()
			new_bullet.position = barrel_origin.global_position if barrel_origin else global_position
			
			var arc_rad = deg_to_rad(arc)
			var increment = arc_rad / (bullet_count - 1)
			new_bullet.global_rotation = (
				global_rotation +
				increment * i -
				arc_rad / 2
			)	
			get_parent().add_child(new_bullet)
		await get_tree().create_timer(1 / fire_rate).timeout
		can_shoot = true
		walking = true

		
func melee_attack() -> void:
	walking = false
	if Global.first_swing == false and is_alive == true:
		animated_sprite.play("bat_attack")
		Global.first_swing = true
	elif Global.first_swing == true and is_alive == true:	
		animated_sprite.play("bat_attack_follow_up")
		Global.first_swing = false	
	await get_tree().create_timer(0.5 / fire_rate).timeout
	walking = true				



func _on_hitbox_area_entered(area: Area2D) -> void:

	if area.is_in_group("Enemy"):
		is_alive = false
		visible = false
		await get_tree().create_timer(0.25).timeout
		get_tree().reload_current_scene()


func _on_reload_speed_timeout() -> void:
	can_shoot = true 


func _on_animated_sprite_2d_animation_finished() -> void:
	if walking == false:
		walking = true
