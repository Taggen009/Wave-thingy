extends Label


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	text = str(Global.highscore)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Global.score > Global.highscore:
		Global.highscore = Global.score
